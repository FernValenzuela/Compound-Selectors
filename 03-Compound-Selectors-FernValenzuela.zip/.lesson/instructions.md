# Instructions  

In this lesson, we'll build:

![compound selector mockup](assets/Compound_Selectors.png)